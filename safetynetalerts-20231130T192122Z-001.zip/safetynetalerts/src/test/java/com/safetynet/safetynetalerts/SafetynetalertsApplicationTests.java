package com.safetynet.safetynetalerts;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SafetynetalertsApplicationTests {

    @Test
    void contextLoads() {
    }

}
