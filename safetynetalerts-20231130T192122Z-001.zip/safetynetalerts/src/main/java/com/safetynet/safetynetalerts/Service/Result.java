package com.safetynet.safetynetalerts.Service;

public enum Result {
    success,
    failure
}
