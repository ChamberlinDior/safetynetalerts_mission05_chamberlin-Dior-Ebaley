package com.safety.netMission05;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NetMission05Application {

	public static void main(String[] args) {
		SpringApplication.run(NetMission05Application.class, args);
	}

}
