package com.safety.netMission05;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NetMission05ApplicationTests {

	@Test
	void contextLoads() {
	}

}
